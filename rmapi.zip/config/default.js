module.exports = {
  server: {
    port: 3333
  },
  authrm: {
    user: 'mestre',
    passwd: 'totvsrm'
  },
  cfg:{
    codcoligada: '1'
  }
};
/*
user: 'rmtotvs',
passwd: 'Gt$#20asd'
*/